
/*
 * Class: CMSC203 CRN 22824
 * Program: Lab 2
 * Instructor: Ahmed Tarek
 * Description: complete task 1-4
 * Due Date: 10/17/2024 
 * Platform/compiler: eclipse
 * I pledge that I have completed the programming assignment 
 * independently. I have not copied the code from a student or   
 * any source. I have not given my code to any student.
 *  Print your Name here: Fernando Terrones

 */

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

/**
 * This panel is the basic panel, inside which other panels are placed.  
 * Before beginning to implement, design the structure of your GUI in order to 
 * understand what panels go inside which ones, and what buttons or other components
 * go in which panels.  
 * @author ralexander
 *
 */
//make the main panel's layout be a VBox
public class FXMainPane extends VBox {

	//student Task #2:
	//  declare five buttons
	Button b1;
	Button b2;
	Button b3;
	Button b4;
	Button b5;
	Button b6;
	//a label
	Label label;
	//textfield
	TextField text;
	//  declare two HBoxes
	HBox h1;
	HBox h2;
	//student Task #4:
	//  declare an instance of DataManager
	/**
	 * The MainPanel constructor sets up the entire GUI in this approach.  Remember to
	 * wait to add a component to its containing component until the container has
	 * been created.  This is the only constraint on the order in which the following 
	 * statements appear.
	 */
	DataManager dataMang =new DataManager();
	FXMainPane() {
		//student Task #2:
		//  instantiate the buttons, label, and textfield
		b1= new Button("Hello");
		b2=new Button("Howdy");
		b3=new Button("Chinese");
		b4=new Button("Clear");
		b5=new Button("Exit");
		b6=new Button("Spanish");
		label=new Label("Feedback:");
		text =new TextField();
		//  instantiate the HBoxes
		h1=new HBox();
		h2=new HBox();
		//student Task #4:
		//  instantiate the DataManager instance
		DataManager dataMang =new DataManager();
        Insets inset = new Insets(6);
		//  set margins and set alignment of the components
		HBox.setMargin(b1, inset);
		HBox.setMargin(b2, inset);
		HBox.setMargin(b3, inset);
		HBox.setMargin(b4, inset);
		HBox.setMargin(b5, inset);
		HBox.setMargin(b6, inset);
		h1.setAlignment(Pos.CENTER);
		h2.setAlignment(Pos.CENTER);
		//student Task #3:
		//  add the label and textfield to one of the HBoxes
		h1.getChildren().addAll(label,text);
		//  add the buttons to the other HBox
		h2.getChildren().addAll(b1,b2,b3,b6,b4,b5);
		//  add the HBoxes to this FXMainPanel (a VBox)
		this.getChildren().addAll(h1,h2);
		
		b1.setOnAction(new ButtonHandler());
		b2.setOnAction(new ButtonHandler());
		b3.setOnAction(new ButtonHandler());
		b4.setOnAction(new ButtonHandler());
		b5.setOnAction(new ButtonHandler());
		b6.setOnAction(new ButtonHandler());



	}
	
	//Task #4:
	//  create a private inner class to handle the button clicks
	 private class ButtonHandler implements EventHandler<ActionEvent>{    	
        //Exercise 4   
		 public void handle(ActionEvent event) {
			 
		            Button b = (Button) event.getTarget();
		            if(b.getText().equals("Hello")) {
		            	text.setText(dataMang.getHello());
		            }
		            else if(b.getText().equals("Howdy")) {
		            	text.setText(dataMang.getHowdy());
		            }
		            else if(b.getText().equals("Chinese")) {
		            	text.setText(dataMang.getChinese());
		            }
		            else if(b.getText().equals("Clear")) {
		            	text.setText("");
		            }
		            else if(b.getText().equals("Exit")) {
		            	Platform.exit();  
		            	System.exit(0); 
		            }
		            else if(b.getText().equals("Spanish")) {
		            	text.setText(dataMang.getSpanish());
		            }
		            
		 }
    	
        
    }
}

	
